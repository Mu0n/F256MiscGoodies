@echo off
setlocal enabledelayedexpansion

REM Path to 7-Zip executable (adjust if needed)
set "SEVENZIP=C:\Program Files\7-Zip\7z.exe"

REM Loop through all .vgz files in current folder
for %%F in (*.vgz) do (
    echo Processing: %%F

    REM Extract into current folder
    "%SEVENZIP%" x "%%F" -y >nul

    REM Expected extracted file: same base name, no extension
    set "BASENAME=%%~nF"

    if exist "!BASENAME!" (
        ren "!BASENAME!" "!BASENAME!.vgm"
        echo Renamed: !BASENAME! → !BASENAME!.vgm
        del "%%F"
    ) else (
        echo ERROR: Expected file "!BASENAME!" not found after extraction.
    )
)

echo All .vgz files processed.
endlocal
