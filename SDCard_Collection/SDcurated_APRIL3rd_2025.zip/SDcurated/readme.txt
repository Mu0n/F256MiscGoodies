Welcome to Mu0n's curated collection of programs and demos
Prepared in March 2025 in anticipation of VCF East in New Jersey in April 2025

(if you're viewing this in moreorless, press Alt-x to exit the program)

This is a collection of working games, demos, applications that at least show something working, if
they are in work-in-progress state.

The best way to peruse the collection is to use Micah's file manager by launching it with:

/- fm

and then browse and press enter on executables: pgz, pgx, pgZ
or on media files: .txt, .mid, .mp3, .wav, .mod to automatically launch the corresponding 
associated app found in the _apps folder, which will in turn open the file and view/play it.


TOOLS AND STEPS TO WRITE ON A FLASH CARTRIDGE
(those steps are in the CartFlasher page of the wiki: https://wiki.f256foenix.com/ ;
however, these programs are already included in this curated collection of software, no need to hunt for them!)

***fcart.pgz is the program that writes something to the flash cartridge
***loader.bin is a small 1 flash block program that acts as a versatile loader menu program that lists all the other KUPs present in your flashcart (a "bootloader")
***cartridge.bin is a small 1 flash block program that does what fcart.pgz is doing but is meant to reside on the cart. If it is there, the flash cart can autonomously write itself.

Run fcart.pgz located in /fcart/

Use fcart.pgz to write loader.bin located in to block 0 of your cartridge; loader.bin is in /fcart/ so you would write fcart/loader.bin to properly target it inside the program fcart.pgz.

Optional: Use fcart.pgz to write cartridge.bin in /fcart/ to block 31 of your cartridge, so you would write fcart/cartridge.bin to properly target it. Now the software to write on the cartridge is on the cartridge itself

Optional: Continue to use fcart.pgz to write pre-converted PGZ programs to a KUP friendly format for the cart, but this involves using a modern computer.

STEP TO CONVERT A PGZ TO A KUP, FLASH CART FRIENDLY PROGRAM
Use pgz2flash https://github.com/rmsk2/pgz2flash/releases to convert all the PGZs files you want to KUPs and store them on the cartridge


INPUT DEVICES REQUIREMENTS:
/demos/f256_life can use a PS/2 mouse to draw pattern
/games/f256_2048 can use joystick in JOY1, SNES Pad top left socket, or just cursor keyboard keys
/games/kartdemo needs a joystick in JOY2
/games/maze needs a joystick in JOY2
/games/missile needs a PS/2 mouse
/GameJamApr24/f256_15 can use joystick in JOY1, SNES Pad top left socket
/GameJamOct25/bachhero can use a MIDI in controller
/GameJamOct24/f256_snake can use joystick in JOY1, SNES Pad top left socket, or just cursor keyboard keys
/GameJamOct24/trickortreat can use JOY2, or keyboard
/games-wip/FusionDrive can use a NES #1, or keyboard
/music/FireJam can use a MIDI in controller


SOUND CHIPS showcasing
PSG: Jr., K, Jr.2, K2
SID: Jr. (only if populated), K, Jr.2, K2
OPL3: K, Jr.2, K2
SAM2695: Jr.2, K2
VS1053b: Jr.2, K2

/music/FireJam can send to PSG, OPL3, SAM2695, VS1053b
/gamejamOct24/trickortreat can send to SID
/gamejamOct24/bachhero can send to PSG and SAM2695 
/games-wip/FusionDrive can send to SAM2695
/games-wip/tetris can send to OPL3
/demos/EdInHisLib can send to SID and OPL3 
/demos/xmas24_k2 can send to PSG 
/_apps/modplayer can send to PSG 
/_apps/audioplayer can send to VS1053b 
/_apps/midiplayer can send to SAM2695 and VS1053b
/ultima3 can send to SID 
/jrtracker.bas can send to PSG
/jrtracker2.bas can send to PSG
/foenixmas23.bas can send to SID


