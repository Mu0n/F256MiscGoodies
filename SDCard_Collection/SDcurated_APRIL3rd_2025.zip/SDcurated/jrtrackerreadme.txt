jrtracker.bas is a PSG tracker program in basic. It supports one pulse signal generator found inside the FPGA, therefore, it can support up to 3 channels.  Tracks made for it have the .trk file extension.

jrtracker2.bas is the same, but it extends support to both PSGs, so it can go up to 6 channels. Tracks made for it have the .tr2 file extension.

a few example tunes are in the root folder (no other way to access them from these programs)
