100  rem "**** variable references ****"
105  progstart = $3b00
110  maxiter = $45ec
115  numiter = $45ed
120  initreal = $45f8
125  initimag = $45fd
130  zoomlevel = $4602
135  defreal = $4640
140  defimag = $4645
145  setzoom = $4b59
150  derive = $4c35
155  xpos = $4606
160  ypos = $4608
165  paramlen = $15
170  paramaddr = $45ee
175  txtrec = $4218
180  clrtxtrec = $4281
185  txtx = $4212
190  txty = $4212+1
195  lenx = $4212+2
200  leny = $4212+3
205  txtcol = $4212+4
210  txtovwr = $4212+5
215  calcintrpt = $4a7a
220  progsig = $4c65
225  plotstate = $4ab3
230  defaultcol1 = $4abc
235  altcol1 = $4ad1
240  colshift = $4ab3+3
245  rem "**** Program text ****"
250  rem
255  bitmapaddr = $10000
260  dim hexfloat(5)
265  resbyte = 0
270  resnibble = 0
275  hexchars$ = "0123456789abcdef"
280  dim zoomx(5)
285  dim zoomy(5)
290  dim keycodes(8)
295  dim keyascii$(8)
300  calcstart$ = ""
305  calcend$ = ""
310  tsstart = 0
315  tsend = 0
320  tsres = 0
325  pad$ = ""
330  prsig$ = "MGSJ"
335  keypressed$ = ""
340  
345  zoomx(0) = 80-2
350  zoomx(1) = 40-2
355  zoomx(2) = 20-2
360  zoomx(3) = 10-2
365  zoomx(4) = 5-2
370  
375  zoomy(0) = 60-2
380  zoomy(1) = 30-2
385  zoomy(2) = 15-2
390  zoomy(3) = 8-2
395  zoomy(4) = 4-2
400  
405  keycodes(0) = 184 
410  keycodes(1) = 185
415  keycodes(2) = 182
420  keycodes(3) = 183
425  keycodes(4) = 105
430  keycodes(5) = 111
435  keycodes(6) = 148
440  keycodes(7) = 113
445  
450  keyascii$(0) = chr$(2)
455  keyascii$(1) = chr$(6)
460  keyascii$(2) = chr$(16)
465  keyascii$(3) = chr$(14)
470  keyascii$(4) = "i"
475  keyascii$(5) = "o"
480  keyascii$(6) = chr$(13)
485  keyascii$(7) = "q"
490  
495  loadmlprog() : print
500  read colshiftval
505  poke colshift, colshiftval
510  
515  cls
520  
525  repeat
530      stopprog = 0
535      print
540      print "***************************************************************************"
545      print "*                                                                         *"
550      print "*                 Mandelbrot set viewer by Martin Grap                    *" 
555      print "*                                                                         *"
560      print "*                           Written in 2023                               *"
565      print "*                                                                         *"
570      print "***************************************************************************"
575      print
580      print "(G)enerate picture"
585      print
590      print "(L)oad picture"
595      print
600      print "(Q)uit"
605      print
610      input "Your selection: "; inp$
615      print
620  
625      if (inp$ = "G") | (inp$ = "g")
630          docalc()
635      endif
640  
645      if (inp$ = "L") | (inp$ = "l")
650          loadpicture()
655      endif
660  
665      if inp$ = "W"
670          poke progsig, 0
675          inp$ = "q"
680      endif
685  until (inp$ = "Q") | (inp$ = "q")
690  
695  cursor on
700  print
705  print "Good bye ..."
710  end
715  
720  proc docalc()
725      local i
730      print "Enter real and imaginary part of upper left corner"
735      input "Real part (return for default)     : "; hfloat$
740      if hfloat$ <> ""
745          converthexfloat(hfloat$)
750      else
755          for i = 0 to 4
760              hexfloat(i) = peek(defreal+i)
765          next
770          print "Using                              : "; : printhexfloat(defreal)
775      endif
780  
785      for i = 0 to 4
790          poke initreal+i, hexfloat(i)
795      next    
800      
805      input "Imaginary part (return for default): "; hfloat$
810      if hfloat$ <> ""
815          converthexfloat(hfloat$)
820      else
825          for i = 0 to 4
830              hexfloat(i) = peek(defimag+i)
835          next
840          print "Using                              : "; : printhexfloat(defimag)
845      endif
850  
855      for i = 0 to 4
860          poke initimag+i, hexfloat(i)
865      next
870  
875      repeat
880          input "Zoom level (min 0, max 16)         : "; zl
885      until (zl >= 0) & (zl <= 16)    
890      poke zoomlevel, zl
895  
900      repeat
905          generatepicture()
910          printcalctime()
915          askforsave()
920          askforzoom()
925      until stopprog
930  
935      print "Done": print
940      printparams("Parameters used:", -1)    
945  endproc
950  
955  proc savepicture()
960      local filename$
965      input "Filename: "; filename$
970      memcopy paramaddr, paramlen to bitmapaddr+320*240
975      bsave filename$, bitmapaddr, 320*240 + paramlen
980  endproc
985  
990  proc generatepicture()
995      repeat
1000         input "Iteration depth (min 1, max 254)   : "; iter
1005     until (iter > 0) & (iter <= 254)
1010     print "OK": 
1015     poke maxiter, iter
1020     cls
1025     calcstart$ = gettime$(0)
1030     call progstart
1035     calcend$ = gettime$(0)
1040     if peek(calcintrpt) = 0
1045         sound 1, 500, 10
1050         waitforkeypress()
1055     endif
1060     clearscreen()
1065 endproc
1070 
1075 proc zerostr(l)
1080     local i
1085     pad$ = ""
1090     i = 0
1095     while i < l
1100         pad$ = pad$ + "0"
1105         i = i + 1
1110     wend
1115 endproc
1120 
1125 proc printcalctime()
1130     local duration, d$, t$, h, d, s
1135     parsetimestamp(calcstart$)
1140     tsstart = tsres
1145     parsetimestamp(calcend$)
1150     tsend = tsres
1155 
1160     if tsend < tsstart
1165         duration = (86400 - tsstart) + tsend
1170     else
1175         duration = tsend - tsstart    
1180     endif
1185 
1190     h = duration \ 3600
1195     s = duration % 3600
1200     m = s \ 60
1205     s = s % 60
1210 
1215     t$ = str$(h) 
1220     zerostr(2 - len(t$))
1225     d$ = pad$ + t$
1230     t$ = str$(m)
1235     zerostr(2 - len(t$))
1240     d$ = d$ + ":" + pad$  + t$
1245     t$ = str$(s)
1250     zerostr(2 - len(t$))
1255     d$ = d$ + ":"  + pad$ + t$
1260 
1265     print
1270     print "Calculation started at : "; calcstart$
1275     print "Calculation ended at   : "; calcend$
1280     print "Duration of calculation: "; d$
1285     print
1290 endproc
1295 
1300 proc parsetimestamp(timestamp$)
1305     local h, m, s
1310 
1315     h = val(mid$(timestamp$, 1, 2))
1320     m = val(mid$(timestamp$, 4, 2))
1325     s = val(mid$(timestamp$, 7, 2))
1330 
1335     tsres = h * 3600 + m * 60 + s
1340 endproc
1345 
1350 proc loadpicture()
1355     local filename$
1360     changedrive()
1365     input "Filename: "; filename$
1370     cls
1375     cursor off
1380     bitmap at bitmapaddr
1385     bitmap on
1390     bitmap clear 2
1395     try bload filename$, bitmapaddr to rc
1400     if rc = 0
1405         memcopy bitmapaddr+320*240, paramlen to paramaddr
1410         waitforkeypress()        
1415         clearscreen()
1420         printparams("Parameters used:", 0): print
1425         askforzoom()
1430 
1435         while not(stopprog)
1440             generatepicture()
1445             printcalctime()
1450             askforsave()
1455             askforzoom()
1460         wend
1465         
1470         print
1475         printparams("Parameters used:", -1): print
1480     else 
1485         clearscreen()               
1490         print "Load error. Press any key."
1495         waitforkeypress()
1500     endif
1505 endproc
1510  
1515 proc waitforkeypress()
1520     repeat
1525        key$ = inkey$() 
1530     until key$ <> ""
1535 endproc
1540 
1545 proc strtonibble(n$)
1550     local code
1555     code = asc(left$(n$,1))
1560     if (code >= asc("0")) & (code <= asc("9"))
1565         resnibble = code-asc("0")
1570     else
1575         if (code >= asc("a")) & (code <= asc("f"))
1580             resnibble = code-asc("a") + 10
1585         else
1590             print "Not valid hex value"
1595             end
1600         endif
1605     endif
1610 endproc
1615  
1620 proc strtobyte(s$)
1625     local b
1630     strtonibble(left$(s$, 1))    
1635     b = 16 * resnibble
1640     strtonibble(right$(s$, 1))
1645     resbyte = b + resnibble
1650 endproc
1655 
1660 proc converthexfloat(v$)
1665     local val$
1670     val$ = v$
1675     if (len(val$) < 9) | (len(val$) > 10)
1680         print "Hexfloat not wellformed!"
1685         end
1690     endif
1695 
1700     sign = 0
1705     if len(val$) = 10 
1710         if left$(val$, 1) = "-"
1715             sign = 1
1720             val$ = right$(val$, len(val$)-1)
1725         endif
1730     endif
1735     hexfloat(0) = sign
1740     strtobyte(left$(val$, 2))
1745     hexfloat(4) = resbyte
1750     strtobyte(mid$(val$, 4, 2))
1755     hexfloat(3) = resbyte
1760     strtobyte(mid$(val$, 6, 2))
1765     hexfloat(2) = resbyte
1770     strtobyte(mid$(val$, 8, 2))
1775     hexfloat(1) = resbyte
1780 endproc
1785 
1790 proc clearscreen()
1795     cursor on
1800     bitmap off
1805     poke $d000,1    
1810     print chr$(128+9)
1815     print chr$(144+2)
1820     print chr$(12)
1825 endproc
1830 
1835 proc printhexbyte(b)
1840     local nibble
1845     nibble = peek(b) \ 16
1850     print mid$(hexchars$, nibble+1, 1);
1855     nibble = peek(b) % 16
1860     print mid$(hexchars$, nibble+1, 1);
1865 endproc
1870 
1875 proc printhexfloat(addr)
1880     local sign$, i
1885     sign$ = " "
1890     if peek(addr) <> 0
1895         sign$ = "-"
1900     endif
1905     print sign$; 
1910     printhexbyte(addr+4)
1915     print ".";
1920     for i = 3 downto 1
1925         printhexbyte(addr+i)
1930     next
1935     print 
1940 endproc
1945 
1950 proc printparams(s$, printiter)
1955     print s$
1960     print "==============="
1965     print "Real part      : ";: printhexfloat(initreal)
1970     print "Imaginary part : ";: printhexfloat(initimag)
1975     print "Zoom level     :  ";: print peek(zoomlevel)
1980     if printiter <> 0
1985         print "Iteration depth:  ";: print peek(maxiter)
1990     endif
1995 endproc
2000 
2005 proc loadmlprog()
2010     local i, s$
2015 
2020     s$ = ""
2025     for i = 0 to 3
2030         s$ = s$ + chr$(peek(progsig + i))
2035     next
2040     print "Loading machine language program ...";
2045     if s$ <> prsig$
2050         try bload "mandel.prg", progstart to rc
2055         if rc <> 0
2060             print "Load error"
2065             end
2070         endif
2075     endif
2080     print " done"
2085 endproc
2090 
2095 proc callrect(x, y, w, h, c, o)
2100       poke txtx, x
2105       poke txty, y
2110       poke lenx, w
2115       poke leny, h
2120       poke txtcol, c
2125       poke txtovwr, o
2130       call txtrec
2135 endproc
2140 
2145 proc callclear(x, y, w, h, c, o)
2150       poke txtx, x
2155       poke txty, y
2160       poke lenx, w
2165       poke leny, h
2170       poke txtcol, c
2175       poke txtovwr, o
2180       call clrtxtrec
2185 endproc
2190 
2195 proc checkkey()
2200     local done, i, delay
2205     done = 0
2210 
2215     repeat
2220         for i = 0 to 7
2225             if keydown(keycodes(i)) 
2230                 while inkey$() <> ""
2235                 wend
2240 
2245                 keypressed$ = keyascii$(i)
2250                 done = 1
2255             endif
2260         next
2265     until done <> 0
2270 endproc
2275 
2280 proc changezoomlevel(currentzoom)
2285     local posy, posy, zoomdelta, width, height, key$, done, col, delay
2290 
2295     cls
2300     cursor off
2305 
2310     for delay = 0 to 1000
2315     next
2320 
2325     posx = 0
2330     posy = 0
2335     zoomdelta = 1
2340     width = zoomx(zoomdelta)
2345     height = zoomy(zoomdelta)
2350     done = 0
2355     col = $F2
2360 
2365     callrect(posx, posy, width, height, col, 0)
2370     
2375     repeat
2380         bitmap on
2385         checkkey()
2390         for delay = 0 to 1000
2395         next        
2400         key$ = keypressed$
2405 
2410         if (key$ = chr$(16)) & (posy > 0)
2415             callclear(posx, posy, width, height, col, 0)
2420             posy = posy -1
2425             callrect(posx, posy, width, height, col, 0)
2430         endif
2435 
2440         if (key$ = chr$(14)) & (posy < 59)
2445             callclear(posx, posy, width, height, col, 0)
2450             posy = posy + 1
2455             callrect(posx, posy, width, height, col, 0)
2460         endif
2465 
2470         if (key$ = chr$(2)) & (posx > 0)
2475             callclear(posx, posy, width, height, col, 0)
2480             posx = posx - 1
2485             callrect(posx, posy, width, height, col, 0)
2490 
2495         endif
2500 
2505         if (key$ = chr$(6)) & (posx < 79)
2510             callclear(posx, posy, width, height, col, 0)
2515             posx = posx + 1
2520             callrect(posx, posy, width, height,col, 0)
2525         endif
2530 
2535         if (key$ = chr$(13))
2540             callclear(posx, posy, width, height, col, 0)
2545             done = -1
2550         endif
2555 
2560         if (key$ = "q")
2565             callclear(posx, posy, width, height, col, 0)
2570             done = -1
2575         endif
2580 
2585         if (key$ = "i" ) & ((currentzoom + zoomdelta) < 16) & (zoomdelta < 4)
2590             callclear(posx, posy, width, height, col, 0)
2595             zoomdelta = zoomdelta + 1
2600             width = zoomx(zoomdelta)
2605             height = zoomy(zoomdelta)
2610             callrect(posx, posy, width, height, col, 0)                
2615         endif
2620 
2625         if (key$ = "o") & (zoomdelta > 0)
2630             callclear(posx, posy, width, height, col, 0)
2635             zoomdelta = zoomdelta - 1
2640             width = zoomx(zoomdelta)
2645             height = zoomy(zoomdelta)
2650             callrect(posx, posy, width, height, col, 0)                
2655         endif
2660     until done
2665 
2670     bitmap off
2675     poke $d000,1
2680 
2685     if key$ <> "q"
2690         poke zoomlevel, currentzoom + zoomdelta
2695         poke xpos, posx
2700         poke ypos, posy
2705         call derive
2710     else
2715         stopprog = -1
2720     endif
2725 
2730     cursor on
2735 endproc
2740 
2745 proc askforzoom()
2750     if peek(zoomlevel) < 16
2755         input "Zoom into picture (y/n)? "; inp$
2760         if inp$ <> "n"
2765             changezoomlevel(peek(zoomlevel))
2770             printparams("New parameters", 0)
2775         else
2780             stopprog = -1
2785         endif
2790     else
2795         stopprog = -1
2800         print "Maximum zoomlevel is reached"
2805     endif
2810 endproc
2815 
2820 proc askforsave()    
2825     input "Save picture (y/n)? "; inp$
2830     if inp$ <> "n" 
2835         changedrive()
2840         savepicture()
2845     endif
2850 endproc
2855 
2860 proc changedrive()
2865     local dr$
2870     repeat
2875         input "Drive 0,1 or 2? "; dr$
2880     until (dr$ = "") | (dr$ = "0") | (dr$ = "1") | (dr$ = "2")
2885     if dr$ <> ""
2890         drive val(dr$)
2895     endif
2900 endproc
2905 
2910 rem "colshiftval"
2915 data 109
�