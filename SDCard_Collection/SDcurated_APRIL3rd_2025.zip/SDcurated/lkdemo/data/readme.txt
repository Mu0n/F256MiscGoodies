this folder is for lk.pgz, which has to stay in the root folder
(Lich King)