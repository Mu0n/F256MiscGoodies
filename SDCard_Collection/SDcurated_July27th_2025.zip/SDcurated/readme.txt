Welcome to Mu0n's curated collection of programs and demos for the F256 for 65C02 and 65816 cores

Initially prepared in March 2025 in anticipation of VCF East in New Jersey in April 2025, it is now continuously updated from time to time.

(if you're viewing this in moreorless, press Alt-x to exit the program)

This is a collection of working games, demos, applications that at least show something working, if
they are in work-in-progress state.

The best way to peruse the collection is to use Micah's file manager by launching it with:

/- fm (if fm is a pgz in the root folder)
/fm (if fm is a flash resident program)

and then browse and press enter on executables: pgz, pgx, pgZ
or on media files: .txt, .mid, .mp3, .wav, .mod to automatically launch the corresponding 
associated app found in the _apps folder, which will in turn open the file and view/play it.

Extension || associated _apps/ program  || original name  || Author
.mid      || midiplayer.pgz             || midisam.pgz    || Mu0n
.mod      || modplayer.pgz              || modo.pgz       || dwsJason, Digarok
.wav      || audioplayer.pgz            || F256amp.pgz    || Mu0n
.mp3      || audioplayer.pgz            || F256amp.pgz    || Mu0n
.ogg      || audioplayer.pgz            || F256amp.pgz    || Mu0n
.wma      || audioplayer.pgz            || F256amp.pgz    || Mu0n
.txt      || textedit.pgz               || mless.pgz      || mgr42

2x 65816 SPEED EXTENDED CORE:
programs which require some functionalities that only exists with the 2x extended map core (paid option under the foenix website) are located in the core2x/ folder.
Features such as faster hardware graphic lines, new text layer mode with more colors, additional bank of 64 sprites and shuffling around of banks of memory to open
up the memory map.


INPUT DEVICES REQUIREMENTS:
/demos/f256_life can use a PS/2 mouse to draw pattern
/games/bbombers.pgx can use a joystick in JOY2
/games/f256_2048 can use joystick in JOY1, SNES Pad top left socket, or just cursor keyboard keys
/games/kartdemo needs a joystick in JOY2
/games/maze needs a joystick in JOY2
/games/missile needs a PS/2 mouse
/GameJamApr24/f256_15 can use joystick in JOY1, SNES Pad top left socket
/GameJamOct25/bachhero can use a MIDI in controller
/GameJamOct24/f256_snake can use joystick in JOY1, SNES Pad top left socket, or just cursor keyboard keys
/GameJamOct24/trickortreat can use JOY2, or keyboard
/games-wip/FusionDrive can use a NES #1, or keyboard
/music/FireJam can use a MIDI in controller


SOUND CHIPS showcasing
PSG: Jr., K, Jr.2, K2
SID: Jr. (only if populated), K, Jr.2, K2
OPL3: K, Jr.2, K2
SAM2695: Jr.2, K2
VS1053b: Jr.2, K2

/_apps/modplayer can send to PSG 
/_apps/audioplayer can send to VS1053b 
/_apps/midiplayer can send to SAM2695 and VS1053b
/core2x/hwline2.bas can send to PSG
/demos/badapple can send to VS1053b 
/demos/EdInHisLib can send to SID and OPL3 
/demos/pendulum can send to SAM2695 
/demos/xmas24_k2 can send to PSG 
/foenixmas23.bas can send to SID
/gamejamOct24/trickortreat can send to SID
/gamejamOct24/bachhero can send to PSG and SAM2695 
/games-wip/FusionDrive can send to SAM2695
/games-wip/tetris can send to OPL3
/jrtracker.bas can send to PSG
/jrtracker2.bas can send to PSG
/music/cozymidi can send to SAM2695, VS1053b
/music/F256Amp can send to VS1053b
/music/FireJam can send to PSG, OPL3, SAM2695, VS1053b
/music/Musik.pzg can send to SAM2695
/ultima3 can send to SID 
/tests/sidtester.bas can send to SID


