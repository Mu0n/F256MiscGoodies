1000 cls
1010 r=c:c=0:x=0:tevent=0:cardpos=1:turnovers=0
1020 onpile=false:onflip=true:selections=0:debugmode=false
1030 dim board(7,7):dim eligcards$(6)
1040 dim positions$(7,7):dim selected(7,7):cardsleft=28
1050 peek=0:pop=0
1060 deck=$7800:pile=$7835:discards=$7853
1070 pilepos=0:pilecard=0:pilecardsel=false
1080 isrunning=1
1090 cls :printcenter("Loading Backgrounds!",0)
1100 bload "background2.pal",$7BFF
1110 loadpal($7BFF,1)
1120 bload "background3.bin",$10000
1130 bitmap on :bitmaplut(0,1)
1140 cls :printcenter("Loading Sprites!",0)
1150 bload "core2deck.bin",$30000
1160 poke $D000,45
1170 cls :gameloop()
1180 end
1190 proc shuffledeck()
1200 cls
1210 printcenter("Shuffling!",0)
1220 swapidx=0:swapval=0
1230 for x=0 to 51
1240 swapidx=random(50)+1
1250 swapval=?(deck+swapidx)
1260 ?(deck+swapidx)=?(deck)
1270 ?(deck)=swapval
1280 swapidx=random(50)+1
1290 swapval=?(deck+swapidx)
1300 ?(deck+swapidx)=?(deck+51)
1310 ?(deck+51)=swapval
1320 next
1330 endproc
1340 proc dealtoboard()
1350 counter=0:index = 0
1360 for r=0 to 6
1370 for c=0 to counter
1380 board(r,c)=?(deck+index)
1390 index=index+1
1400 next
1410 counter=counter+1
1420 next
1430 cardsleft=index
1440 endproc
1450 proc dealtopile()
1460 for x=0 to 23
1470 ?(pile+x)=?(deck+(x+29))
1480 next
1490 endproc
1500 proc initboard()
1510 for x=0 to 6:for y=0 to 6:board(x,y)=255:next:next
1520 for x=0 to 23:?(discards+x)=255:next
1530 endproc
1540 proc setup()
1550 for x=1 to 52:?(deck+x)=x:next
1560 initboard()
1570 shuffledeck()
1580 dealtoboard()
1590 dealtopile()
1600 bitmaplut(0,1)
1610 sprites on
1620 sprite 0 image 54
1630 renderboard()
1640 renderpile()
1650 scanforelig()
1660 cardsleft=28
1670 endproc
1680 proc renderboard()
1690 cardx=160
1700 cardy=185
1710 counter=6
1720 spritecounter=1
1730 yoffset=0
1740 for r=6 downto 0
1750 cardx=160-(16*counter)
1760 for c=0 to counter
1770 cardno=board(r,c)
1780 if selected(r,c) = 1
1790 yoffset=5
1800 else
1810 yoffset=0
1820 endif
1830 if cardno < 255
1840 sprite spritecounter image cardno to cardx,cardy+yoffset
1850 positions$(r,c)=str$(cardx)+":"+str$(cardy+yoffset)
1860 else
1870 sprite spritecounter off
1880 endif
1890 spritecounter=spritecounter+1
1900 cardx=cardx+33
1910 next
1920 counter=counter-1
1930 cardy=cardy-28
1940 next
1950 cls
1960 print at 55,60 str$(cardsleft)" Cards Left"
1970 endproc
1980 proc renderpile()
1990 sprite 52 image 52 to 135,220
2000 sprite 54 image 53 to 188,220
2010 endproc
2020 proc popoffpile()
2030 pilecard=?(pile)
2040 pilecardsel=false
2050 sprite 53 image pilecard to 188,220
2060 if pilecard=52
2070 if turnovers=3
2080 turnovers=0
2090 gameover()
2100 else
2110 idx=0
2120 for x=22 downto 0
2130 if ?(discards+x) < 52
2140 ?(pile+idx)=?(discards+x)
2150 idx=idx+1
2160 endif
2170 next
2180 turnovers=turnovers+1
2190 endif
2200 endif
2210 for x=0 to 22
2220 ?(pile+x)=?(pile+(x+1))
2230 next
2240 pushdiscard(pilecard)
2250 endproc
2260 proc pushdiscard(cardno)
2270 if ?(discards) = 255
2280 ?(discards)=cardno
2290 else
2300 for x=23 downto 1
2310 ?(discards+x)=?(discards+(x-1))
2320 next
2330 ?(discards) = cardno
2340 endif
2350 endproc
2360 proc trashdiscard()
2370 for x=0 to 22
2380 ?(discards+x)=?(discards+(x+1))
2390 next
2400 endproc
2410 proc reversepop()
2420 if pilecardsel=true
2430 trashdiscard()
2440 endif
2450 pilecard=?(discards)
2460 if pilecard < 52
2470 pilecardsel=false
2480 sprite 53 image pilecard to 188,220
2490 else
2500 sprite 53 image 53 to 188,220
2510 endif
2520 endproc
2530 proc printdebugstuff()
2540 print at 0,0 "";
2550 for x=0 to 6:print eligcards$(x):next
2560 print "p: "+str$(cardpos)" d: "str$(onpile)" s:"+str$(selections)
2570 print "pc: "str$(pilecard)" ps: "str$(pilecardsel)" t:"str$(turnovers)
2580 print
2590 for x=0 to 23:print ?(pile+x)" ";:next
2600 print
2610 for x=0 to 23:print ?(discards+x)" ";:next
2620 endproc
2630 proc updatecursorpos()
2640 if onpile=false
2650 elig$=eligcards$(cardpos-1)
2660 if itemcount(elig$,":") = 4
2670 x=val(itemget$(elig$,3,":"))
2680 y=val(itemget$(elig$,4,":"))
2690 sprite 0 to x,y
2700 endif
2710 else
2720 if onflip=false
2730 sprite 0 to 188,220
2740 else
2750 sprite 0 to 135,220
2760 endif
2770 endif
2780 endproc
2790 proc handleselection()
2800 if selections < 2
2810 if onpile = false
2820 elig$=eligcards$(cardpos-1)
2830 if itemcount(elig$,":") = 4
2840 boardpos$=itemget$(elig$,2,":")
2850 r=val(itemget$(boardpos$,1,","))
2860 c=val(itemget$(boardpos$,2,","))
2870 selected(r,c)=1
2880 selections=selections+1
2890 if selections=1 then sound 1,427,10
2900 if selections=2 then sound 1,339,10
2910 endif
2920 else
2930 if onflip=true
2940 popoffpile()
2950 zap
2960 selections=0
2970 pilecardsel=false
2980 else
2990 pilecardsel=true
3000 selections=selections+1
3010 if selections=1 then sound 1,427,10
3020 if selections=2 then sound 1,339,10
3030 sprite 53 to 193,220
3040 endif
3050 endif
3060 checkscore()
3070 else
3080 selections=0
3090 resetselections()
3100 endif
3110 renderboard()
3120 endproc
3130 proc resetselections()
3140 for r=0 to 6
3150 for c=0 to 6
3160 selected(r,c)=0
3170 next
3180 next
3190 selections=0
3200 pilecardsel=false
3210 endproc
3220 proc deleteselected()
3230 for r=0 to 6
3240 for c=0 to 6
3250 if selected(r,c)=1
3260 selected(r,c)=0
3270 board(r,c)=255
3280 cardsleft=cardsleft-1
3290 endif
3300 next
3310 next
3320 if cardsleft=0 then win()
3330 selections=0
3340 sprite 53 off
3350 reversepop()
3360 pilecardsel=false
3370 scanforelig()
3380 renderboard()
3390 endproc
3400 proc checkscore()
3410 total=0
3420 for r=0 to 6
3430 for c=0 to 6
3440 if selected(r,c)=1
3450 value=(board(r,c)+1)%13
3460 if value=0
3470 total=total+13
3480 else
3490 total=total+value
3500 endif
3510 endif
3520 next
3530 next
3540 if pilecardsel=true
3550 value=(pilecard+1)%13
3560 if value=0
3570 total=total+13
3580 else
3590 total=total+value
3600 endif
3610 endif
3620 if total=13
3630 sound 1,427,20:sound 2,339,20:sound 0,284,20
3640 deleteselected()
3650 endif
3660 endproc
3670 proc scanforelig()
3680 entry=0
3690 for x=0 to 6:eligcards$(x)="":next
3700 for c=0 to 6
3710 for r=6 downto 0
3720 pos$=positions$(r,c)
3730 if r=6&(board(r,c)<255)
3740 eligcards$(entry)=str$(board(r,c))+":"+str$(r)+","+str$(c)+":"+pos$
3750 entry=entry+1
3760 else
3770 if board(r,c)<255&board(r+1,c)=255&board(r+1,c+1)=255
3780 if len(eligcards$(c))=0
3790 eligcards$(entry)=str$(board(r,c))+":"+str$(r)+","+str$(c)+":"+pos$
3800 entry=entry+1
3810 endif
3820 endif
3830 endif
3840 next
3850 next
3860 if cardpos > entry then cardpos=entry
3870 endproc
3880 proc bitmaplut(bitmapno,lutno)
3890 if bitmapno>=0&bitmapno<3&lutno>=0&lutno<4
3900 add$="53504,53512,53520"
3910 value=val(itemget$(add$,bitmapno+1,","))
3920 current=?(value)
3930 poke value,(1|1<<lutno)
3940 endif
3950 endproc
3960 proc loadpal(addr,lutno)
3970 lutaddr=$D000+(lutno*$400)
3980 poke 1,1
3990 for x=0 to 1023:?(lutaddr+x)=?(addr+x):next
4000 endproc
4010 proc printcenter(msg$, yoffset)
4020 xoffset=len(msg$)\2
4030 print at 30+yoffset,(40-xoffset)msg$
4040 endproc
4050 proc updatekey()
4060 local keypress
4070 keypress=inkey()
4080 if (keypress=2)|(joyx(0)=-1)
4090 if cardpos > 1 & onpile=false
4100 cardpos = cardpos-1
4110 sound 0,10,1
4120 endif
4130 if onpile=true
4140 onflip=true
4150 endif
4160 endif
4170 if (keypress=6)|(joyx(0)=1)
4180 if cardpos < 7 & onpile=false
4190 cardpos = cardpos+1
4200 sound 0,10,1
4210 endif
4220 if onpile=true
4230 onflip=false
4240 endif
4250 endif
4260 if (keypress=14)|(joyy(0)=1)
4270 onpile=true
4280 endif
4290 if (keypress=16)|(joyy(0)=-1)
4300 onpile=false
4310 endif
4320 if (keypress=32)|(joyb(0)&1)
4330 handleselection()
4340 endif
4350 if keypress=130
4360 if debugmode=false
4370 debugmode=true
4380 else
4390 debugmode=false
4400 cls
4410 endif
4420 endif
4430 endproc
4440 proc gameloop()
4450 setup()
4460 repeat
4470 if event(tevent,5)
4480 updatekey()
4490 updatecursorpos()
4500 if debugmode=true
4510 printdebugstuff()
4520 endif
4530 endif
4540 until isrunning=0
4550 endproc
4560 proc gameover()
4570 sprites off:cls:isover=false
4580 cls
4590 sound 3,500,20
4600 printcenter("GAME OVER!",0)
4610 printcenter("Play Again [Y/N]?",1)
4620 rect color 2 solid 120,110 to 200,140
4630 repeat
4640 a=inkey()
4650 if a=121
4660 gameloop()
4670 endif
4680 if a=110 then isover=true
4690 until isover
4700 sprites off:bitmap clear 10:cls
4710 endproc
4720 proc win()
4730 cls:isover=false
4740 cls:spriteno=1
4750 sound 3,500,20
4760 repeat
4770 sprite spriteno image spriteno to random(320),random(240)
4780 if spriteno < 52
4790 spriteno=spriteno+1
4800 else
4810 spriteno=1
4820 endif
4830 rect color 2 solid 120,110 to 200,140
4840 printcenter("YOU WON!",0)
4850 printcenter("Play Again [Y/N]?",1)
4860 a=inkey()
4870 if a=121
4880 gameloop()
4890 endif
4900 if a=110 then isover=true
4910 until isover
4920 sprites off:bitmap clear 10:cls
4930 endproc
????
