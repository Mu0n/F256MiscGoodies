1000 cls
1010 bload "pylaunch1.pal",$7BFF
1020 loadpal($7BFF,1)
1030 bload "pylaunch1.bin",$10000
1040 bitmap on :bitmaplut(0,1)
1050 rect color 0 solid 10,12 to 102,73
1060 rect color 7 solid 10,10 to 100,70
1070 print at 4,4 "";:pctext("FALLITAIRE")
1080 print at 6,4 "";:pctext("A BFG Game Jam Entry")
1090 print at 8,4 "";:pctext("Use Joystick/Fire")
1100 print at 10,4 "";:pctext("or Keyboard/Space")
1110 print at 15,4 "";:pctext("Press F1 To Begin")
1120 print at 59,51 "2025 JeffD/ProgrammerVsWorld";
1130 gameloop()
1140 end
1150 proc gameloop()
1160 isrunning=true
1170 local keypress
1180 while isrunning=true
1190 keypress=inkey()
1200 if keypress=129
1210 cls
1220 isrunning=false
1230 loadgame()
1240 endif
1250 wend
1260 endproc
1270 proc loadpal(addr,lutno)
1280 lutaddr=$D000+(lutno*$400)
1290 poke 1,1
1300 for x=0 to 1023:?(lutaddr+x)=?(addr+x):next
1310 endproc
1320 proc bitmaplut(bitmapno,lutno)
1330 if bitmapno>=0&bitmapno<3&lutno>=0&lutno<4
1340 add$="53504,53512,53520"
1350 value=val(itemget$(add$,bitmapno+1,","))
1360 current=?(value)
1370 poke value,(1|1<<lutno)
1380 endif
1390 endproc
1400 proc pctext(message$)
1410 event1=0:event2=0
1420 counter=1
1430 repeat
1440 if event(event1,random(10))
1450 print mid$(message$,counter,1);
1460 counter=counter+1
1470 endif
1480 until counter=len(message$)+1
1490 endproc
1500 proc loadgame()
1510 memcopy $28000,$8000 poke 0
1520 a$="pbas.bas":bload a$,$28000:xgo
1530 endproc
????
