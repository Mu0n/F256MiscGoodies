
## Launch with Mame:

    ./f256 f256k -skip_gameinfo -window -resolution 800x600 -harddisk leaderboard.img

## Keyboard Instructions:

    <D>                     Demo
    <R>                     Driving Range (Practice)
    <F3>                    Skip Hole

## Joystick Instructions:

    <Up>/<Down>             Change Club
    <Left>/<Right>          Move Aim Pointer
    <Button>                Swing

## Mame Joystick Emulation:

    <Arrow><Up>/<Down>      Change Club
    <Arrow><Left>/<Right>   Move Aim Pointer
    <L-Ctrl>                Swing
