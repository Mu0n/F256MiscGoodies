
## F256 Switcharoo

A strategic puzzle game for the **Foenix/Wildbits F256** retro computer, built with **llvm-mos**. Play against a heuristic Engine opponent in this unique piece-swapping strategy game.

## Game Overview

Switcharoo is a two-player abstract strategy game where players compete to create a connected path of their pieces across the board.

### Board and Players

- **Board**: 8 rows × 4 columns
- **Players**: White (human, bottom) vs Black (Engine, top)
- **Objective**: Create a connected path of your pieces linking rows 2 through 7

### Movement Rules

- **Empty Cell Move**: Move one piece to any adjacent cell (8 directions). This may clear swapped pieces depending on the active swap rule.
- **Swap Move**: Move to an adjacent cell occupied by an opponent's NORMAL piece. Both pieces exchange positions and become SWAPPED.
- **Swapped Pieces**: Cannot be the target of a swap, but can initiate swaps with NORMAL opponent pieces.

### Swap Rule Variants

| Mode | Behavior |
|------|----------|
| Classic | Moving into an empty cell clears ALL swapped pieces |
| Clears Own | Moving into an empty cell clears only the mover's swapped pieces |
| Swapped Clears | Only swapped pieces moving to empty cells trigger the clear |
| Swapped Clears Own | Swapped pieces moving to empty clear only the mover's pieces |

## Features

- **Puzzle Mode**: Solve pre-designed puzzles with optimal move sequences
- **Free Play Mode**: Open gameplay against the Engine with multiple starting layouts
- **Engine Difficulty Levels**: Adjustable Engine strength from easy to advanced
- **Achievements System**: Track your progress and accomplishments
- **Move History**: Review and navigate through past moves
- **Mouse & Keyboard Support**: Full input support for both control methods
- **Audio**: Sound effects for moves, wins, and losses

## Running on Emulator
1. Copy `switcheroo.pgz` to the emulated SD Card
2. Load the program through the command prompt.

NOTE: When run on the Foenix IDE use the spacebar to progress the Splash and Exit screens.  The SID sound
routine on those screens requires a timer, which is not working in the IDE.  Playback can be bypassed by selecting the
space key.

## Running on Hardware

1. Copy `switcheroo.pgz` to your F256 SD card
2. Boot the F256 and load the program
Game should run on core1x or core2x gen1 and gen2 f256 hardware. 

## Puzzle Loading
1. The pgz file has 100 built-in puzzles. Twenty-five for each Swap Rule Variant
2. The additional puzzle sets included in the distribution can be loaded by renaming the file switcheroo.puz
3. On startup, the game looks for switcheroo.puz in the starting directory and uses it to overwrite the built-in puzzle set.
4. Loading a new puzzle set will reset achievements and puzzle solution status that is saved in persistent storage (switcheroo.dat)

## Engine Heuristics

The Engine evaluates moves using multiple factors:

**Connection Progress**
- Rows occupied in the victory span (rows 2-7)
- Number of connected rows in the victory span

**Bridge Potential**
- Empty cells available for path expansion

**Swap Pressure**
- Swapped pieces restrict opponent movement options (cannot be swap targets)

**Blocking Coverage**
- Pieces in center columns of victory rows
- Adjacency for movement restriction and further swap opportunities

**Mobility**
- Total legal moves available

**Win/Loss detection:**
- Immediate win detection
- Forced win sequences (win-in-2, win-in-3)
- Loss avoidance and forcing move recognition

## Controls

### Keyboard

- **Arrow Keys**: Navigate board/menu
- **Enter**: Select piece or confirm move
- **Escape**: Deselect piece or dismiss overlay

### Mouse

- **Left Click**: Select pieces and execute moves
- **Hover**: Visual feedback on interactive elements

## License

See repository [switcheroo](https://github.com/jbaker8935/switcheroo) for license information.

## Acknowledgments

- Built for the [Foenix F256](https://wiki.f256foenix.com/index.php?title=Main_Page) retro computer
- Compiled with [llvm-mos](https://github.com/llvm-mos/llvm-mos-sdk)


## Release History

1.0 - Initial Release
1.1 - Using starting directory for puz and dat files.  Minor fixes.

